import os
from src.recon import DRM
from src.degrad_classify import Diff_NoImg_DC, Diff_DC
os.environ['CUDA_VISIBLE_DEVICES'] = '0,1'
os.environ['NCCL_P2P_DISABLE'] = '1'
os.environ['NCCL_IB_DISABLE'] = '1'
import sys
import argparse
from data.universal_dataset import AlignedDataset_all
from src.model import (ResidualDiffusion, Trainer,  UnetRes, set_seed)

def parsr_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataroot", type=str, default='/home/data/')
    parser.add_argument("--phase", type=str, default='train')
    parser.add_argument("--max_dataset_size", type=int, default=float("inf"))
    parser.add_argument('--load_size', type=int, default=268, help='scale images to this size') #572,268
    parser.add_argument('--crop_size', type=int, default=256, help='then crop to this size')
    parser.add_argument('--direction', type=str, default='AtoB', help='AtoB or BtoA')
    parser.add_argument('--preprocess', type=str, default='crop', help='scaling and cropping of images at load time [resize_and_crop | crop | scale_width | scale_width_and_crop | none]')
    parser.add_argument('--no_flip', action='store_true', help='if specified, do not flip the images for data augmentation')
    parser.add_argument("--bsize", type=int, default=2)
    opt = parser.parse_args()
    return opt

sys.stdout.flush()
set_seed(10)
save_and_sample_every = 10000
if len(sys.argv) > 1:
    sampling_timesteps = int(sys.argv[1])
else:
    sampling_timesteps = 2

train_batch_size = 10
num_samples = 1
sum_scale = 0.01
image_size = 256
condition = True
opt = parsr_args()
results_folder = "./ckpt_universal/diffuir"
refine_ckpt_path= '/home/exp_5/DRM.pth'

if 'universal' in results_folder:   # *************** TASK**************
    dataset_fog = AlignedDataset_all(opt, image_size, augment_flip=True, equalizeHist=True, crop_patch=True, generation=False, task='fog')
    dataset_light = AlignedDataset_all(opt, image_size, augment_flip=True, equalizeHist=True, crop_patch=True, generation=False, task='light_only')
    dataset_rain = AlignedDataset_all(opt, image_size, augment_flip=True, equalizeHist=True, crop_patch=True, generation=False, task='rain')
    dataset_snow = AlignedDataset_all(opt, image_size, augment_flip=True, equalizeHist=True, crop_patch=True, generation=False, task='snow')
    dataset_blur = AlignedDataset_all(opt, image_size, augment_flip=True, equalizeHist=True, crop_patch=True, generation=False, task='blur')
    dataset = [dataset_fog, dataset_light, dataset_rain, dataset_snow, dataset_blur]
    
    num_unet = 1
    objective = 'pred_res'
    test_res_or_noise = "res"
    train_num_steps = 400000
    train_batch_size = 10
    sum_scale = 0.01
    delta_end = 1.8e-3

DRM_model = DRM(
    in_channel=3,
    dim=24,
    mid_blk_num=3,
    enc_blk_nums=[1, 1, 1, 1],
    dec_blk_nums=[1, 1, 1, 1]
)

cls_model = Diff_DC(
    feature_dims=[24, 48, 96, 192],
    num_res_blocks=2,
    num_classes=5
)

model = UnetRes(
    dim=32,
    dim_mults=(1, 2, 2, 4),
    num_unet=num_unet,
    condition=condition,
    objective=objective,
    test_res_or_noise = test_res_or_noise,
wave_condition = True
)

diffusion = ResidualDiffusion(
    model,
    refine_model=DRM_model ,
    cls_model=cls_model,
    refine_ckpt_path=refine_ckpt_path,
    image_size=image_size,
    timesteps=1000,           # number of steps
    delta_end = delta_end,
    sampling_timesteps=sampling_timesteps,
    objective=objective,
    loss_type='l1',            # L1 or L2
    condition=condition,
    sum_scale=sum_scale,
    test_res_or_noise = test_res_or_noise,
    wave_cond=True
)

trainer = Trainer(
    diffusion,
    dataset,
    opt,
    train_batch_size=train_batch_size,
    num_samples=num_samples,
    train_lr=8e-5,
    train_num_steps=train_num_steps,         # total training steps
    gradient_accumulate_every=2,    # gradient accumulation steps
    ema_decay=0.995,                # exponential moving average decay
    amp=False,                        # turn on mixed precision
    results_folder = results_folder,
    condition=condition,
    save_and_sample_every=save_and_sample_every,
    num_unet=num_unet,
)

# train
#trainer.load()
trainer.train()
